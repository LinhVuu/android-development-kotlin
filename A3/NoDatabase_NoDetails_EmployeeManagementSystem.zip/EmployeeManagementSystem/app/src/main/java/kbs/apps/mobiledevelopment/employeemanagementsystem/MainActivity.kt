// https://stackoverflow.com/questions/37598165/how-do-i-allow-users-to-upload-images-to-my-app-and-use-them/37598432#37598432

package kbs.apps.mobiledevelopment.employeemanagementsystem


import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import java.time.LocalDate

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: EmployeeAdapter
    private val employeeViewModel: EmployeeViewModel by viewModels() // Kotlin property delegate

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Setup RecyclerView
        recyclerView = findViewById(R.id.recyclerViewEmployee)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val data = initData()

        adapter = EmployeeAdapter (data)
//        adapter = EmployeeAdapter()
        recyclerView.adapter = adapter

//        employeeViewModel.allEmployees.observe(this) { employees ->
//            adapter.submitList(employees)
//        }
    }

//    private fun showDetail(item: Employee) {
//        val intent = Intent(this, DetailActivity::class.java)
//        intent.putExtra("employee", employee)
//        startActivity(intent)
//    }

    private fun initData(): ArrayList<Employee> {
        val alEmployee = ArrayList<Employee>()

        alEmployee.add(
            Employee(
                imageUri = "snow_white",
                firstName = "Snow",
                lastName = "White",
                gender = "Female",
                birthday = LocalDate.of(1995, 3, 1),
                phone = "+61987654321",
                email = "snow.white@kbs.edu.au",
                location = "Australia",
                position = "Data Analyst",
                department = "IT",
                reportTo = "Linh Vuu",
                dateHired = LocalDate.of(2025, 3, 1),
                startDate = LocalDate.of(2025, 3, 1),
                isOngoing = true,
                endDate = LocalDate.of(2026, 3, 1),
                emergencyContact = "+61987654321"
            )
        )

        alEmployee.add(
            Employee(
                imageUri = "snow_white",
                firstName = "Snow",
                lastName = "White",
                gender = "Female",
                birthday = LocalDate.of(1995, 3, 1),
                phone = "+61987654321",
                email = "snow.white@kbs.edu.au",
                location = "Australia",
                position = "Data Analyst",
                department = "IT",
                reportTo = "Linh Vuu",
                dateHired = LocalDate.of(2025, 3, 1),
                startDate = LocalDate.of(2025, 3, 1),
                isOngoing = true,
                endDate = LocalDate.of(2026, 3, 1),
                emergencyContact = "+61987654321"
            )
        )

        return alEmployee
    }
}