package kbs.apps.mobiledevelopment.employeemanagementsystem

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(entities = [Employee::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
public abstract class EmployeeDatabase : RoomDatabase()
{
    abstract fun employeeDao(): EmployeeDao

    companion object
    {
        @Volatile
        private var INSTANCE: EmployeeDatabase? = null

        fun getDatabase(context: Context): EmployeeDatabase
        {
            return INSTANCE ?: synchronized(this)
            {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EmployeeDatabase::class.java,
                    "employee_database"
                ).addCallback(AppDatabaseCallback(context))
//                )
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Launch on background thread to avoid blocking UI
            CoroutineScope(Dispatchers.IO).launch {
                getDatabase(context).employeeDao().insertEmployee(
                    Employee(
                        imageUri = "snow_white",
                        firstName = "Snow",
                        lastName = "White",
                        gender = "Female",
                        birthday = LocalDate.of(1995, 3, 1),
                        phone = "+61987654321",
                        email = "snow.white@kbs.edu.au",
                        location = "Australia",
                        position = "Data Analyst",
                        department = "IT",
                        reportTo = "Linh Vuu",
                        dateHired = LocalDate.of(2025, 3, 1),
                        startDate = LocalDate.of(2025, 3, 1),
                        isOngoing = true,
                        endDate = LocalDate.of(2026, 3, 1),
                        emergencyContact = "+61987654321"
                    )
                )
            }
        }
    }
}