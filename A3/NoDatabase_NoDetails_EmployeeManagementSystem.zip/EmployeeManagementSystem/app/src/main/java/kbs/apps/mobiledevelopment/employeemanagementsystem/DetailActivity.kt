package kbs.apps.mobiledevelopment.employeemanagementsystem

import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//
//        val ivPoster = findViewById<ImageView>(R.id.ivPoster)
//        val tvName = findViewById<TextView>(R.id.tvName)
//        val tvDirector = findViewById<TextView>(R.id.tvDirector)
//        val tvStars = findViewById<TextView>(R.id.tvStars)
//        val tvSource = findViewById<TextView>(R.id.tvSource)
//
//        val i = intent
//        val movie: Movie?
//
//        if (Build.VERSION.SDK_INT >= 33) {
//            movie = i?.getParcelableExtra("movie", Movie::class.java)
//        } else {
//            @Suppress("DEPRECATION")
//            movie = i?.getParcelableExtra("movie")
//        }
//
//        movie?.let {
//            ivPoster.setImageResource(it.poster)
//            tvName.text= buildString {
//                append(it.name)
//                append(" (")
//                append(it.year)
//                append(")")
//
//            }
//            tvDirector.text = buildString {
//                append("Directed by\n")
//                append(it.director)
//            }
//            tvStars.text = buildString {
//                append("Starring\n")
//                append(formatStars(it.stars))
//            }
//        }

//        tvSource.text = "Image source\nhttps://www.adobe.com/express/templates/poster/movie"
    }

    fun formatStars(stars: List<String>): String {
        return when (stars.size) {
            0 -> ""
            1 -> stars[0]
            2 -> "${stars[0]} and ${stars[1]}"
            else -> {
                val allButLast = stars.dropLast(1).joinToString(", ")
                "$allButLast, and ${stars.last()}"
            }
        }
    }
}