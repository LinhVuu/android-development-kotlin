package kbs.apps.mobiledevelopment.employeemanagementsystem

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.core.net.toUri

class EmployeeAdapter(private val employeeList: ArrayList<Employee>) :
    RecyclerView.Adapter<EmployeeAdapter.EmployeeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmployeeViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_list_employees, parent, false)
        return EmployeeViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return employeeList.size
    }

    override fun onBindViewHolder(holder: EmployeeViewHolder, position: Int) {
        val employee = employeeList[position]
        holder.bind(employee)
    }

    inner class EmployeeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val fullName: TextView = itemView.findViewById(R.id.textViewFullName)
        private val photo: ImageView = itemView.findViewById(R.id.imageViewPhoto)

        fun bind(employee: Employee) {
            fullName.text = employee.getFullName()
            employee.imageUri?.let { imageName ->
                val resId = itemView.context.resources.getIdentifier(imageName, "drawable", itemView.context.packageName)
                if (resId != 0) {
                    photo.setImageResource(resId)
                } else {
                    photo.setImageResource(R.drawable.kaplan_logo_white_transparent_rgb) // fallback if not found
                }
            }
            itemView.setOnClickListener { _: View ->
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra("employee", employee)
                itemView.context.startActivity(intent)
            }
        }
    }
}